# 階段0 第4批：SpeechMessage.Dynamics.Plugins

你是唯讀外部審查者。本輪為「單模型（使用者指定 ClaudeOnly）」，不是雙模型或配額降級。只審查，不改檔、不提交、不執行產品／工具／測試，不建立任何網路或 D365／LINE 連線。
審查重點：跨使用者／跨教會隔離、資源釋放、機密外洩、例外責任（設計10.5／10.9）、net48/net10行為一致、守門假綠燈。所有真實連線驗收仍由使用者負責。
機密欄位已遮罩；遮罩值不可用來推斷實際設定正確性。不得讀取 appsettings*、User Secrets、環境變數、Logs、金鑰／授權檔，或以 git show 取未遮罩版本。只以所附安全差異審查；如需上下文，可只查明確的非機密程式來源。不要開啟 .ccg/dual-model-runs 的其他歷史輸出或 research 原始紀錄。
輸出只列可驗證的 Critical／High／Medium／Low，包含檔案、行號、觸發條件、具體影響及最小修法；測試不足須說明可重現的缺口，不把純猜測當發現。沒有問題請明寫。不得聲稱實跑測試。
已核定例外：嚴格 .Tests 測試專案僅 CA1707 放寬；未實作 API 的 CA1716 可改語意近名；Core 不通知，Plugin 僅追蹤，最終告警在 net10 重試用盡／階段5；正式金鑰只程序環境且不讀內容；本階段不存在業務 Rejected。小組頁面由使用者確認恢復，圖表未逐項驗證，之前審查兩次為逾時。

範圍：73b6e6cf409daa7559fd3c11d482e3efc542c0d7..ae29cb40aa5c395f83c169068d7ca40e7094c509
安全差異 SHA256：bf25a8bd0d6832c596052434fc286490fd2172c65183d9dea4054071760f037b
同批其他分份須一併審查後才算完成，本份不可代表全批。
專項：沙箱 Plugin 寫 ITracingService 後拋出／重新拋出；Retryable 保留 TransportException InnerException，Permanent 只追蹤；不寫 Exception.log、不發管理者 LINE；簽章與合併只四個核定輸入；net48 嚴格稽核。

```diff
diff --git a/.trellis/spec/backend/plugin-packaging-contract.md b/.trellis/spec/backend/plugin-packaging-contract.md
new file mode 100644
index 00000000..442f1433
--- /dev/null
+++ b/.trellis/spec/backend/plugin-packaging-contract.md
@@ -0,0 +1,93 @@
+# Plugin Packaging Contract
+
+## 1. Scope / Trigger
+
+P0-10 builds the net48 DiagnosticsPingPlugin shell and a separate deployment DLL.
+All verification is offline. No package test or build connects to D365 or LINE.
+
+## 2. Signatures
+
+```powershell
+dotnet build SpeechMessage.Dynamics.Plugins -c Release -p:SpeechMessagePackagePlugin=true -p:SpeechMessageBuildNumber=37
+powershell -NoProfile -File tools/PluginPackaging/Test-PluginAssembly.ps1
+powershell -NoProfile -File tools/PluginPackaging/Tests/Test-PluginAssembly.Tests.ps1
+powershell -NoProfile -File tools/PluginPackaging/Tests/Test-PluginBuild.Tests.ps1
+# CI sample mode (temporary test key only):
+powershell -NoProfile -File tools/PluginPackaging/Tests/Test-PluginBuild.Tests.ps1 -UseEphemeralTestKey
+dotnet test tools/PluginPackaging.Tests -c Release
+```
+
+The checker optionally accepts `-AssemblyPath <file-or-local-wildcard>`.
+It emits one JSON result per DLL and fails the whole run if any DLL fails.
+
+## 3. Contracts
+
+- `ILRepackTargetsFile` points to `build/PluginMerge.targets`. The package's
+  default target merges every bin DLL, overwrites the primary assembly, and
+  deletes dependencies; that breaks test type identity and can embed SDK DLLs.
+- Merge exactly the primary DLL, Localization, Core, and Newtonsoft.Json.
+  Internalize dependencies, leave Xrm SDK external, and write only the dedicated
+  `artifacts/plugins` deployment output. Never overwrite the original test DLL.
+- Read the formal key only from process environment
+  `SPEECHMESSAGE_PLUGIN_KEYFILE`. Do not read, copy, print, or record its contents.
+  Never generate a replacement formal key.
+- Packaging is opt-in (user approval 2026-11-03): only
+  `SpeechMessagePackagePlugin=true` executes the merge target. Ordinary Debug
+  and Release builds never enter it, read the signing key, or create artifacts.
+  CI without a signing secret must build and test normally, then report packaging
+  as skipped. CI with a secret restores it only to runner temp and always cleans
+  it in a separate `if: always()` step; never print or upload the key.
+- Missing key: Release packaging fails with SMP0001; Debug emits SMP0002 and an
+  unsigned output. A configured missing file fails with SMP0003.
+- AssemblyVersion remains 1.0.0.0. FileVersion and InformationalVersion carry
+  `SpeechMessageBuildNumber`, default 1, supplied by the build when publishing.
+- The .NET 10 helper uses System.Reflection.Metadata/PEReader, never loads or
+  executes the target DLL. It closes its stream before returning.
+- All request/context/result state stays local to Execute. Only immutable step
+  configuration is retained on the reusable plugin instance. Core alone owns
+  HTTP and its ten-second operation timeout.
+- Retryable failures preserve the original transport exception as InnerException;
+  unexpected failures trace only the type and rethrow the same exception.
+  Stage 0-4 monitoring uses system jobs and plugin traces; no notifier or file
+  logging is added to the sandbox.
+
+## 4. Validation & Error Matrix
+
+| Input / condition | Required result |
+| --- | --- |
+| Signed net48 public DiagnosticsPingPlugin, allowed references, under 16 MiB | JSON ok=true, exit 0 |
+| No public key/token or no StrongNameSigned flag | strongName=false, exit 1 |
+| Wrong/missing TargetFrameworkAttribute | targetFramework=false, exit 1 |
+| Reference outside mscorlib, System, System.*, Xrm SDK/Proxy | allowedReferences=false, exit 1 |
+| System.Drawing or a child reference | noDrawing=false, exit 1 |
+| Missing/private diagnostic type | diagnosticsPlugin=false, exit 1 |
+| Length at least 16 MiB, corrupt PE, unavailable input | Fail closed with fixed reason, no original path/message |
+| Mixed directory containing valid and invalid DLLs | Inspect every DLL; aggregate exit 1 |
+
+## 5. Good / Base / Bad Cases
+
+- Good: merged deployment DLL passes metadata checks while unit tests keep the
+  original bin assembly and dependency identities.
+- Base: a trace-only invocation sends no HTTP and writes both diagnostic cultures.
+- Bad: treating an arbitrary compile/restore failure as a functional red test,
+  executing target assemblies during inspection, or merging bin/*.dll.
+
+## 6. Tests Required
+
+Preserve the seven planned plugin methods and two approved exception methods.
+Add bounded A/B registration reuse with a shared HTTP client, drain counters,
+configuration rejection, and synchronization-context tests.
+Keep ordinary Debug/Release-without-key builds, opt-in missing/invalid-key
+failures, and signed/unsigned samples and independently inject framework, dependency,
+visibility, drawing, size, image and mixed-directory faults. Temporary test
+keys belong to a unique fixture, are never formal keys, and must be deleted.
+The in-process helper suite must also prove immediate exclusive file reopening;
+its writer is operation-owned, avoiding global Console replacement in tests.
+
+## 7. Wrong vs Correct
+
+Wrong: ILRepack takes every bin DLL and writes back into the plugin test output;
+the test process sees two assemblies claiming the same referenced Core types.
+
+Correct: an explicit four-input merge writes to artifacts, while the unmerged
+bin DLL and SDK references remain unchanged for the normal build/test graph.

diff --git a/SpeechMessage.Dynamics.Plugins.Tests/DiagnosticsPingPluginTests.cs b/SpeechMessage.Dynamics.Plugins.Tests/DiagnosticsPingPluginTests.cs
new file mode 100644
index 00000000..49476376
--- /dev/null
+++ b/SpeechMessage.Dynamics.Plugins.Tests/DiagnosticsPingPluginTests.cs
@@ -0,0 +1,393 @@
+using System;
+using System.Collections.Generic;
+using System.Globalization;
+using System.Linq;
+using System.Net;
+using System.Net.Http;
+using System.Threading;
+using System.Threading.Tasks;
+using LineMessagingProcessor.Core;
+using Microsoft.Xrm.Sdk;
+using Moq;
+using SpeechMessage.Dynamics.Plugins.Diagnostics;
+using Newtonsoft.Json.Linq;
+using Xunit;
+
+namespace SpeechMessage.Dynamics.Plugins.Tests;
+
+/// <summary>
+/// 完全離線驗證外掛邊界；以 Moq 提供 SDK 服務、假 handler 注入 HTTP 狀態及原始例外。
+/// 每案例獨佔 provider、追蹤集合與 HttpClient，確認不輸出機密、不吞錯、傳輸及服務參考不跨執行保留。
+/// </summary>
+public sealed class DiagnosticsPingPluginTests
+{
+    /// <summary>只在測試中使用的合成憑證，不對應任何 LINE channel。</summary>
+    private const string Token = "synthetic-plugin-token";
+    /// <summary>符合單人推播格式的合成收件者，不對應真實聯絡人。</summary>
+    private const string UserId = "[REDACTED_LINE_ID]";
+
+    /// <summary>trace 模式不得送 HTTP；斷言標記、組件、執行環境、觸發事件及兩語系實際取字結果。</summary>
+    [Fact(DisplayName = "追蹤模式寫入診斷與雙語文字")]
+    public void Execute_TraceMode_WritesPingAndBothCultures()
+    {
+        using var fixture = new Fixture();
+        fixture.Create("trace").Execute(fixture.Provider.Object);
+        var trace = string.Join("\n", fixture.Traces);
+        Assert.Contains("P0-PING OK", trace, StringComparison.Ordinal);
+        Assert.Contains("SpeechMessage.Dynamics.Plugins, Version=1.0.0.0", trace, StringComparison.Ordinal);
+        Assert.Contains("FrameworkFileVersion=", trace, StringComparison.Ordinal);
+        Assert.Contains("EnvironmentVersion=", trace, StringComparison.Ordinal);
+        Assert.Contains("連線測試成功", trace, StringComparison.Ordinal);
+        Assert.Contains("［連線測試成功ǂǂǂ］", trace, StringComparison.Ordinal);
+        Assert.Contains("account", trace, StringComparison.Ordinal);
+        Assert.Contains("Update", trace, StringComparison.Ordinal);
+        Assert.Equal(0, fixture.Handler.Calls);
+    }
+
+    /// <summary>固定 UTC 時鐘與實體 ID，斷言真實 Core HTTP 標頭及單則推播內容，不驗證替身自行設定的結果。</summary>
+    [Fact(DisplayName = "推播重試鍵來自主實體識別")]
+    public void Execute_PushMode_UsesPrimaryEntityIdAsRetryKey()
+    {
+        using var fixture = new Fixture();
+        fixture.Create().Execute(fixture.Provider.Object);
+        Assert.Equal(fixture.EntityId.ToString("D", CultureInfo.InvariantCulture), fixture.Handler.RetryKey);
+        Assert.Contains("P0 推播測試 2026-11-03T00:00:00.0000000+00:00", fixture.Handler.Body!, StringComparison.Ordinal);
+        Assert.Equal(1, fixture.Handler.Calls);
+        Assert.True(fixture.Handler.ContentDisposed);
+    }
+
+    /// <summary>以合成 token／userId 送訊，追蹤只允許分類、安全狀態與請求診斷鍵，不能夾帶憑證或收件者。</summary>
+    [Theory(DisplayName = "推播追蹤永不包含憑證與收件者")]
+    [InlineData(200)]
+    [InlineData(401)]
+    [InlineData(429)]
+    public void Execute_PushMode_TraceNeverContainsToken(int status)
+    {
+        using var fixture = new Fixture(status);
+        var error = Record.Exception(() => fixture.Create().Execute(fixture.Provider.Object));
+        var trace = string.Join("\n", fixture.Traces);
+        Assert.DoesNotContain(Token, trace, StringComparison.Ordinal);
+        Assert.DoesNotContain(UserId, trace, StringComparison.Ordinal);
+        Assert.DoesNotContain("P0 推播測試", trace, StringComparison.Ordinal);
+        if (error is not null) Assert.DoesNotContain(Token, error.Message, StringComparison.Ordinal);
+        Assert.Contains(status.ToString(CultureInfo.InvariantCulture), trace, StringComparison.Ordinal);
+    }
+
+    /// <summary>以 429／5xx 注入可重試結果，必須追蹤分類並以 SDK 例外退出；訊息只有通用文字與事件鍵。</summary>
+    [Theory(DisplayName = "可重試 HTTP 故障交系統作業處理")]
+    [InlineData(429)]
+    [InlineData(500)]
+    public void Execute_Retryable_ThrowsInvalidPluginExecutionException(int status)
+    {
+        using var fixture = new Fixture(status);
+        var error = Assert.Throws<InvalidPluginExecutionException>(() => fixture.Create().Execute(fixture.Provider.Object));
+        Assert.Contains(fixture.EntityId.ToString("D", CultureInfo.InvariantCulture), error.Message, StringComparison.Ordinal);
+        Assert.Null(error.InnerException);
+        Assert.Contains("Retryable", string.Join("\n", fixture.Traces), StringComparison.Ordinal);
+    }
+
+    /// <summary>以 401 注入永久失敗，外掛只追蹤分類且不拋出，避免非同步作業盲目重試。</summary>
+    [Fact(DisplayName = "永久失敗只追蹤不拋出")]
+    public void Execute_Permanent_DoesNotThrow()
+    {
+        using var fixture = new Fixture(401);
+        fixture.Create().Execute(fixture.Provider.Object);
+        Assert.Contains("Permanent", string.Join("\n", fixture.Traces), StringComparison.Ordinal);
+        Assert.Equal(1, fixture.Handler.Calls);
+    }
+
+    /// <summary>以重入深度二注入遞迴事件，斷言沒有追蹤與 HTTP，且不讀取實體內容。</summary>
+    [Fact(DisplayName = "深度大於一直接返回")]
+    public void Execute_DepthGreaterThanOne_DoesNothing()
+    {
+        using var fixture = new Fixture();
+        fixture.Context.SetupGet(value => value.Depth).Returns(2);
+        fixture.Create().Execute(fixture.Provider.Object);
+        Assert.Empty(fixture.Traces);
+        Assert.Equal(0, fixture.Handler.Calls);
+        fixture.Context.VerifyGet(value => value.PrimaryEntityId, Times.Never);
+    }
+
+    /// <summary>注入損毀 JSON／無效模式語系；拒絕訊息必須為繁中固定文字，不能回顯輸入或 JSON 解析例外。</summary>
+    [Theory(DisplayName = "不合法註冊設定以安全繁中訊息拒絕")]
+    [InlineData("{synthetic-secret")]
+    [InlineData("null")]
+    [InlineData("{\"mode\":\"invalid\",\"culture\":\"zh-TW\"}")]
+    [InlineData("{\"mode\":\"trace\",\"culture\":\"invalid\"}")]
+    public void Ctor_InvalidUnsecureJson_ThrowsWithChineseMessage(string config)
+    {
+        var error = Assert.Throws<InvalidPluginExecutionException>(() => new DiagnosticsPingPlugin(config, Token));
+        Assert.Contains("設定", error.Message, StringComparison.Ordinal);
+        Assert.DoesNotContain("synthetic", error.Message, StringComparison.Ordinal);
+        Assert.Null(error.InnerException);
+    }
+
+    /// <summary>Core 的無回應故障保留原始 HttpRequestException；外掛必須以同一實例作 InnerException，不輸出訊息。</summary>
+    [Fact(DisplayName = "可重試傳輸例外保留原始內層例外")]
+    public void Execute_Retryable_PreservesTransportExceptionAsInner()
+    {
+        using var fixture = new Fixture();
+        var original = new HttpRequestException("synthetic-sensitive-network-detail");
+        fixture.Handler.Reply = (_, _) => throw original;
+        var error = Assert.Throws<InvalidPluginExecutionException>(() => fixture.Create().Execute(fixture.Provider.Object));
+        Assert.Same(original, error.InnerException);
+        var trace = string.Join("\n", fixture.Traces);
+        Assert.Contains(typeof(HttpRequestException).FullName!, trace, StringComparison.Ordinal);
+        Assert.DoesNotContain(original.Message, trace + error.Message, StringComparison.Ordinal);
+    }
+
+    /// <summary>非預期程式故障先追蹤型別再以 throw 重拋；同一例外必須離開外掛，訊息不可進追蹤。</summary>
+    [Fact(DisplayName = "非預期例外追蹤後保持原始實例重拋")]
+    public void Execute_UnexpectedException_TracesAndRethrows()
+    {
+        using var fixture = new Fixture();
+        var original = new InvalidOperationException("synthetic-sensitive-programming-detail");
+        fixture.Handler.Reply = (_, _) => throw original;
+        Assert.Same(original, Assert.Throws<InvalidOperationException>(() => fixture.Create().Execute(fixture.Provider.Object)));
+        var trace = string.Join("\n", fixture.Traces);
+        Assert.Contains(typeof(InvalidOperationException).FullName!, trace, StringComparison.Ordinal);
+        Assert.DoesNotContain(original.Message, trace, StringComparison.Ordinal);
+    }
+
+    /// <summary>注入重複鍵、錯誤型別、過長設定與非法收件者，固定拒絕且不保留敏感輸入作內層例外。</summary>
+    /// <param name="fault">固定故障選擇，不接受外部設定。</param>
+    [Theory(DisplayName = "診斷設定邊界拒絕不合法值")]
+    [InlineData("empty")]
+    [InlineData("long")]
+    [InlineData("duplicate")]
+    [InlineData("unknown")]
+    [InlineData("wrong-type")]
+    [InlineData("user")]
+    [InlineData("token")]
+    public void Ctor_ConfigurationBoundary_FailsClosed(string fault)
+    {
+        var config = "{\"mode\":\"push\",\"culture\":\"zh-TW\",\"lineUserId\":\"" + UserId + "\"}";
+        config = fault switch
+        {
+            "empty" => "",
+            "long" => new string('x', 4097),
+            "duplicate" => "{\"mode\":\"push\",\"mode\":\"trace\",\"culture\":\"zh-TW\"}",
+            "unknown" => "{\"mode\":\"trace\",\"culture\":\"zh-TW\",\"other\":\"synthetic-sensitive\"}",
+            "wrong-type" => "{\"mode\":2,\"culture\":\"zh-TW\"}",
+            "user" => config.Replace(UserId, "synthetic-sensitive-user"),
+            _ => config
+        };
+        var error = Assert.Throws<InvalidPluginExecutionException>(() => new DiagnosticsPingPlugin(config, fault == "token" ? "" : Token));
+        Assert.Equal("診斷外掛設定格式錯誤。", error.Message);
+        Assert.Null(error.InnerException);
+    }
+
+    /// <summary>
+    /// 同一無狀態 HTTP client 供 A／B 外掛重用，各自執行二十次；真正 Core 必須每次取到正確憑證、收件者及事件鍵。
+    /// 兩路並行且每次更換 provider，所有回應內容在 Execute 返回前釋放，停止後活躍數回到零。
+    /// </summary>
+    [Fact(DisplayName = "重用外掛與共用傳輸維持步驟隔離並排空資源")]
+    public async Task Execute_ConcurrentRegistrationReuse_IsolatedAndDrained()
+    {
+        using var handler = new IsolationHandler();
+        using var http = new HttpClient(handler) { Timeout = Timeout.InfiniteTimeSpan };
+        var client = new LinePushClient(http);
+        var pluginA = new DiagnosticsPingPlugin("{\"mode\":\"push\",\"culture\":\"zh-TW\",\"lineUserId\":\"" + UserId + "\"}", Token,
+            client, () => new DateTimeOffset(2026, 11, 3, 0, 0, 0, TimeSpan.Zero));
+        var pluginB = new DiagnosticsPingPlugin("{\"mode\":\"push\",\"culture\":\"qps-ploc\",\"lineUserId\":\"[REDACTED_LINE_ID]\"}",
+            "synthetic-plugin-token-B", client, () => new DateTimeOffset(2026, 11, 3, 0, 0, 0, TimeSpan.Zero));
+        await Task.WhenAll(Task.Run(() => Run(pluginA, "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")),
+            Task.Run(() => Run(pluginB, "bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee")));
+        Assert.Equal(40, handler.Calls);
+        Assert.Equal(0, handler.Active);
+        Assert.Equal(0, handler.Mismatches);
+
+        static void Run(DiagnosticsPingPlugin plugin, string id)
+        {
+            for (var index = 0; index < 20; index++)
+            {
+                using var fixture = new Fixture();
+                fixture.Context.SetupGet(value => value.PrimaryEntityId).Returns(Guid.Parse(id));
+                plugin.Execute(fixture.Provider.Object);
+                Assert.DoesNotContain("synthetic-plugin-token", string.Join("\n", fixture.Traces), StringComparison.Ordinal);
+            }
+        }
+    }
+
+    /// <summary>會丟棄 Post 的同步內容代表不能回到原執行緒；外掛須在有界等待內完成且釋放回應。</summary>
+    [Fact(DisplayName = "同步沙箱內容不會攔住非同步推播完成")]
+    public void Execute_SynchronizationContext_CompletesAndDisposes()
+    {
+        using var fixture = new Fixture();
+        using var content = new TrackedContent();
+        fixture.Handler.Reply = async (_, _) =>
+        {
+            await Task.Yield();
+            return new HttpResponseMessage(HttpStatusCode.OK) { Content = content };
+        };
+        var previous = SynchronizationContext.Current;
+        var context = new RejectingContext();
+        try
+        {
+            SynchronizationContext.SetSynchronizationContext(context);
+            fixture.Create().Execute(fixture.Provider.Object);
+            Assert.Equal(1, fixture.Handler.Calls);
+            Assert.Equal(0, context.Posts);
+            Assert.True(content.Disposed);
+        }
+        finally { SynchronizationContext.SetSynchronizationContext(previous); }
+    }
+
+    /// <summary>被驗證的沙箱同步內容，任何回到呼叫執行緒的排程都直接拒絕，不建立背景執行緒。</summary>
+    private sealed class RejectingContext : SynchronizationContext
+    {
+        /// <summary>排程次數應維持零，避免靠等待逾時判斷死結。</summary>
+        public int Posts { get; private set; }
+        /// <summary>故障注入不執行 callback，若產品捕獲此外部內容便立刻失敗。</summary>
+        /// <param name="d">不應被捕獲的回呼。</param>
+        /// <param name="state">不應滯留的呼叫狀態。</param>
+        public override void Post(SendOrPostCallback d, object? state)
+        {
+            Posts++;
+            throw new InvalidOperationException("Sandbox synchronization context was captured.");
+        }
+    }
+
+    /// <summary>共用連線池的無狀態替身；只保留有界計數，不保存 request、憑證或訊息原文。</summary>
+    private sealed class IsolationHandler : HttpMessageHandler
+    {
+        /// <summary>以原子操作計算傳輸次數。</summary>
+        private int calls;
+        /// <summary>已建立但尚未 Dispose 的回應內容數量。</summary>
+        private int active;
+        /// <summary>隔離契約失敗次數，不保存失敗原文。</summary>
+        private int mismatches;
+        /// <summary>停止後的總操作數。</summary>
+        public int Calls => calls;
+        /// <summary>停止後必須為零的資源數。</summary>
+        public int Active => active;
+        /// <summary>停止後必須為零的配對錯誤數。</summary>
+        public int Mismatches => mismatches;
+        /// <summary>以真實 Core 組出的標頭及 JSON 檢查 A／B 配對，每次建立獨立的回應內容。</summary>
+        /// <param name="request">只在這次 await 期間存活，不存入欄位。</param>
+        /// <param name="cancellationToken">由 Core 擁有的十秒取消鏈。</param>
+        /// <returns>交回 Core using owner 的獨立回應。</returns>
+        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
+        {
+            Interlocked.Increment(ref calls);
+            var body = JObject.Parse(await request.Content!.ReadAsStringAsync().ConfigureAwait(false));
+            var tokenA = string.Equals(request.Headers.Authorization!.Parameter, Token, StringComparison.Ordinal);
+            var expectedId = tokenA ? UserId : "[REDACTED_LINE_ID]";
+            var expectedKey = tokenA ? "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee" : "bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee";
+            if (!string.Equals((string?)body["to"], expectedId, StringComparison.Ordinal) ||
+                !string.Equals(request.Headers.GetValues("X-Line-Retry-Key").Single(), expectedKey, StringComparison.Ordinal))
+                Interlocked.Increment(ref mismatches);
+            Interlocked.Increment(ref active);
+            return new HttpResponseMessage(HttpStatusCode.OK)
+            {
+                Content = new DrainContent(() => Interlocked.Decrement(ref active))
+            };
+        }
+    }
+
+    /// <summary>由 Core 唯一擁有的回應內容；Dispose 只回報一次並解除回呼，不能滯留測試 owner。</summary>
+    private sealed class DrainContent : StringContent
+    {
+        /// <summary>最多存活至這次回應 Dispose 的資源釋放回呼。</summary>
+        private Action? release;
+        /// <summary>建立單次回應資源計數。</summary>
+        /// <param name="release">測試 owner 的有界計數回呼。</param>
+        public DrainContent(Action release) : base("{}") => this.release = release;
+        /// <summary>原子解除回呼避免重複扣數，再交基底釋放串流。</summary>
+        /// <param name="disposing">是否由 owner 明確釋放。</param>
+        protected override void Dispose(bool disposing)
+        {
+            if (disposing) Interlocked.Exchange(ref release, null)?.Invoke();
+            base.Dispose(disposing);
+        }
+    }
+
+    /// <summary>單案例的 SDK／HTTP owner；不建立真實組織服務或任何網路 fallback。</summary>
+    private sealed class Fixture : IDisposable
+    {
+        /// <summary>固定合成業務事件鍵，每個 fixture 各自持有且不來自真實 D365。</summary>
+        public Guid EntityId { get; } = new("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee");
+        /// <summary>追蹤資料僅限此案例；Dispose 清空，不跨測試共享。</summary>
+        public List<string> Traces { get; } = new();
+        /// <summary>Moq SDK 服務提供者，只提供本案例的執行內容與追蹤服務。</summary>
+        public Mock<IServiceProvider> Provider { get; } = new(MockBehavior.Strict);
+        /// <summary>合成執行內容，讓深度與 RetryKey 契約可被決定性斷言。</summary>
+        public Mock<IPluginExecutionContext> Context { get; } = new(MockBehavior.Strict);
+        /// <summary>可注入故障的離線傳輸，所有回應資源由 Core 釋放。</summary>
+        public Handler Handler { get; }
+        /// <summary>此 fixture 的唯一連線池 owner，結束時 Dispose。</summary>
+        private readonly HttpClient http;
+        /// <summary>建立最小 SDK 情境；追蹤格式使用明確 invariant culture，不依賴主機文化。</summary>
+        public Fixture(int status = 200)
+        {
+            Context.SetupGet(value => value.Depth).Returns(1);
+            Context.SetupGet(value => value.PrimaryEntityId).Returns(EntityId);
+            Context.SetupGet(value => value.PrimaryEntityName).Returns("account");
+            Context.SetupGet(value => value.MessageName).Returns("Update");
+            var tracing = new Mock<ITracingService>(MockBehavior.Strict);
+            tracing.Setup(value => value.Trace(It.IsAny<string>(), It.IsAny<object[]>()))
+                .Callback<string, object[]>((format, args) => Traces.Add(string.Format(CultureInfo.InvariantCulture, format, args)));
+            Provider.Setup(value => value.GetService(typeof(ITracingService))).Returns(tracing.Object);
+            Provider.Setup(value => value.GetService(typeof(IPluginExecutionContext))).Returns(Context.Object);
+            Handler = new Handler(status);
+            http = new HttpClient(Handler) { Timeout = Timeout.InfiniteTimeSpan };
+        }
+        /// <summary>使用真實 Core 配合假 handler；時間固定，不連線或等待系統時間。</summary>
+        /// <param name="mode">trace 或 push，依案例選定。</param>
+        /// <returns>只在此案例存活的外掛實例。</returns>
+        public DiagnosticsPingPlugin Create(string mode = "push") =>
+            new("{\"mode\":\"" + mode + "\",\"culture\":\"zh-TW\",\"lineUserId\":\"" + UserId + "\"}", Token,
+                new LinePushClient(http), () => new DateTimeOffset(2026, 11, 3, 0, 0, 0, TimeSpan.Zero));
+        /// <summary>由單一 owner 關閉 HttpClient／handler 並清除合成追蹤資料，沒有 fire-and-forget。</summary>
+        public void Dispose() { http.Dispose(); Traces.Clear(); }
+    }
+
+    /// <summary>擷取單次 HTTP 的合成資料與內容生命週期；不得落到預設網路 handler。</summary>
+    private sealed class Handler : HttpMessageHandler
+    {
+        /// <summary>故障注入委派只存活於此測試 fixture。</summary>
+        public Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> Reply { get; set; }
+        /// <summary>送出次數，保護深度守門及沒有內部重試。</summary>
+        public int Calls { get; private set; }
+        /// <summary>當次事件鍵快照，不保留完整 request。</summary>
+        public string? RetryKey { get; private set; }
+        /// <summary>合成訊息快照，Dispose 清除，不寫入證據。</summary>
+        public string? Body { get; private set; }
+        /// <summary>追蹤回應是否由 Core 明確釋放，與 GC 無關。</summary>
+        public bool ContentDisposed => content?.Disposed == true;
+        /// <summary>僅持有合成回應內容供決定性釋放斷言。</summary>
+        private readonly TrackedContent content = new();
+        /// <summary>配置固定狀態回應，不提供真實端點或驗證機密。</summary>
+        public Handler(int status) => Reply = (_, _) =>
+        {
+            var response = new HttpResponseMessage((HttpStatusCode)status) { Content = content };
+            response.Headers.Add("x-line-request-id", "11111111-2222-3333-4444-555555555555");
+            return Task.FromResult(response);
+        };
+        /// <summary>先複製必要合成資料再交給故障注入，回應由 Core 的 using owner 接管。</summary>
+        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
+        {
+            Calls++;
+            RetryKey = string.Join("", request.Headers.GetValues("X-Line-Retry-Key"));
+            Body = await request.Content!.ReadAsStringAsync().ConfigureAwait(false);
+            return await Reply(request, cancellationToken).ConfigureAwait(false);
+        }
+        /// <summary>測試 owner 結束時釋放未送出的內容，並丟棄合成快照。</summary>
+        protected override void Dispose(bool disposing)
+        {
+            if (disposing) { content.Dispose(); Body = RetryKey = null; }
+            base.Dispose(disposing);
+        }
+    }
+
+    /// <summary>單次回應內容的明確 Dispose 證據，不以程序結束代替清理。</summary>
+    private sealed class TrackedContent : StringContent
+    {
+        /// <summary>內容是否已被擁有者確定性釋放。</summary>
+        public bool Disposed { get; private set; }
+        /// <summary>固定合成內容不含任何真實資料。</summary>
+        public TrackedContent() : base("{}") { }
+        /// <summary>釋放前留下布林計數，再交基底清理串流。</summary>
+        protected override void Dispose(bool disposing) { if (disposing) Disposed = true; base.Dispose(disposing); }
+    }
+}

diff --git a/SpeechMessage.Dynamics.Plugins.Tests/SpeechMessage.Dynamics.Plugins.Tests.csproj b/SpeechMessage.Dynamics.Plugins.Tests/SpeechMessage.Dynamics.Plugins.Tests.csproj
new file mode 100644
index 00000000..286cb45c
--- /dev/null
+++ b/SpeechMessage.Dynamics.Plugins.Tests/SpeechMessage.Dynamics.Plugins.Tests.csproj
@@ -0,0 +1,23 @@
+<Project Sdk="Microsoft.NET.Sdk">
+  <PropertyGroup>
+    <TargetFramework>net48</TargetFramework>
+    <SpeechMessageStrictCode>true</SpeechMessageStrictCode>
+    <GenerateDocumentationFile>true</GenerateDocumentationFile>
+    <IsTestProject>true</IsTestProject>
+    <IsPackable>false</IsPackable>
+    <AutoGenerateBindingRedirects>true</AutoGenerateBindingRedirects>
+    <GenerateBindingRedirectsOutputType>true</GenerateBindingRedirectsOutputType>
+  </PropertyGroup>
+  <ItemGroup>
+    <PackageReference Include="Microsoft.NETFramework.ReferenceAssemblies" PrivateAssets="all" />
+    <PackageReference Include="Microsoft.NET.Test.Sdk" />
+    <PackageReference Include="Microsoft.CrmSdk.CoreAssemblies" PrivateAssets="all" />
+    <PackageReference Include="System.Text.Json" PrivateAssets="all" />
+    <PackageReference Include="Moq" />
+    <PackageReference Include="xunit" />
+    <PackageReference Include="xunit.runner.visualstudio" PrivateAssets="all" />
+    <PackageReference Include="coverlet.collector" PrivateAssets="all" />
+    <ProjectReference Include="../SpeechMessage.Dynamics.Plugins/SpeechMessage.Dynamics.Plugins.csproj" />
+    <Reference Include="System.Net.Http" />
+  </ItemGroup>
+</Project>

diff --git a/SpeechMessage.Dynamics.Plugins/Diagnostics/DiagnosticsPingPlugin.cs b/SpeechMessage.Dynamics.Plugins/Diagnostics/DiagnosticsPingPlugin.cs
new file mode 100644
index 00000000..bce15aa1
--- /dev/null
+++ b/SpeechMessage.Dynamics.Plugins/Diagnostics/DiagnosticsPingPlugin.cs
@@ -0,0 +1,146 @@
+using System;
+using System.Globalization;
+using System.Linq;
+using System.Reflection;
+using System.Threading;
+using System.Threading.Tasks;
+using LineMessagingProcessor.Core;
+using Microsoft.Xrm.Sdk;
+using Newtonsoft.Json;
+using Newtonsoft.Json.Linq;
+using SpeechMessage.Localization;
+
+namespace SpeechMessage.Dynamics.Plugins.Diagnostics;
+
+/// <summary>
+/// 階段零的沙箱診斷外殼；只保存不可變註冊設定，執行內容及傳輸資源不得跨執行保留。
+/// Core 擁有每次 HTTP 訊息及十秒逾時；外掛只追蹤安全欄位並在邊界重新拋出真正失敗。
+/// </summary>
+public sealed class DiagnosticsPingPlugin : IPlugin
+{
+    /// <summary>只包含固定資源的唯讀表，不承載教會、使用者、token 或執行內容。</summary>
+    private static readonly SystemTextTable Texts = new();
+    /// <summary>註冊設定的不可變模式；沙箱可重用外掛，但不得寫入此次 Execute 的狀態。</summary>
+    private readonly bool pushMode;
+    /// <summary>此註冊步驟選定的文字語系，不改程序或執行緒文化。</summary>
+    private readonly string culture;
+    /// <summary>只屬此 secure 註冊步驟的不可變憑證；不進 static、追蹤或其他步驟。</summary>
+    private readonly LineChannelCredential? credential;
+    /// <summary>只屬此測試步驟的固定收件者；執行時不由輸入內容覆寫，也不寫追蹤。</summary>
+    private readonly string? userId;
+    /// <summary>無使用者狀態的 Core 入口；外掛不保存它回傳的結果或原始例外。</summary>
+    private readonly ILinePushClient client;
+    /// <summary>UTC 時鐘的無狀態委派；測試可固定時間，不持有 provider 或執行內容。</summary>
+    private readonly Func<DateTimeOffset> utcNow;
+
+    /// <summary>供沙箱以註冊設定建立診斷外掛，不接受由執行內容提供的憑證。</summary>
+    /// <param name="unsecureConfig">只有模式、語系與測試收件者的 JSON。</param>
+    /// <param name="secureConfig">此步驟專屬測試 channel token；不得追蹤或進入共用狀態。</param>
+    public DiagnosticsPingPlugin(string unsecureConfig, string secureConfig)
+        : this(unsecureConfig, secureConfig, new LinePushClient(), ReadUtcNow) { }
+
+    /// <summary>供離線測試注入 Core 及時鐘；不建立新的通知或背景工作接點。</summary>
+    /// <param name="unsecureConfig">已核定的診斷 JSON。</param>
+    /// <param name="secureConfig">僅此外掛實例持有的合成憑證。</param>
+    /// <param name="client">單次呼叫 Core 能力，其 HTTP 連線池由沙箱或測試 owner 擁有。</param>
+    /// <param name="utcNow">不捕獲執行內容的 UTC 時鐘。</param>
+    internal DiagnosticsPingPlugin(string unsecureConfig, string secureConfig, ILinePushClient client, Func<DateTimeOffset> utcNow)
+    {
+        this.client = client ?? throw new ArgumentNullException(nameof(client));
+        this.utcNow = utcNow ?? throw new ArgumentNullException(nameof(utcNow));
+        try
+        {
+            if (string.IsNullOrWhiteSpace(unsecureConfig) || unsecureConfig.Length > 4096) throw InvalidConfiguration();
+            var config = JObject.Parse(unsecureConfig, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
+            if (config.Properties().Any(property => property.Name is not ("mode" or "culture" or "lineUserId"))) throw InvalidConfiguration();
+            var mode = ReadString(config, "mode");
+            culture = ReadString(config, "culture");
+            if (mode is not ("trace" or "push") || culture is not ("zh-TW" or "qps-ploc")) throw InvalidConfiguration();
+            pushMode = string.Equals(mode, "push", StringComparison.Ordinal);
+            if (pushMode)
+            {
+                userId = ReadString(config, "lineUserId");
+                if (!IsValidUserId(userId)) throw InvalidConfiguration();
+                credential = new LineChannelCredential(secureConfig);
+            }
+        }
+        catch (JsonException) { throw InvalidConfiguration(); }
+        catch (ArgumentException) { throw InvalidConfiguration(); }
+    }
+
+    /// <summary>深度守門後追蹤雙語文字，必要時推播並依分類處理例外；不得保留 provider。</summary>
+    /// <param name="serviceProvider">這次執行唯一的服務來源，不存入欄位或 static。</param>
+    public void Execute(IServiceProvider serviceProvider)
+    {
+        if (serviceProvider is null) throw new ArgumentNullException(nameof(serviceProvider));
+        var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
+        try
+        {
+            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
+            if (context.Depth > 1) return;
+            tracing.Trace("P0-PING OK");
+            tracing.Trace("Assembly={0}", typeof(DiagnosticsPingPlugin).Assembly.FullName);
+            tracing.Trace("FrameworkFileVersion={0}", typeof(object).Assembly.GetCustomAttribute<AssemblyFileVersionAttribute>()?.Version);
+            tracing.Trace("EnvironmentVersion={0}", Environment.Version.ToString());
+            var key = new TextKey("Common.Diagnostics.Ping");
+            tracing.Trace("zh-TW={0}", Texts.GetText("zh-TW", key));
+            tracing.Trace("qps-ploc={0}", Texts.GetText("qps-ploc", key));
+            tracing.Trace("Entity={0}; Message={1}", SafeIdentifier(context.PrimaryEntityName), SafeIdentifier(context.MessageName));
+            if (!pushMode) return;
+            var retryKey = context.PrimaryEntityId;
+            var text = Texts.GetText(culture, new TextKey("Common.Diagnostics.PushTest"))
+                .Replace("{utc}", utcNow().ToUniversalTime().ToString("O", CultureInfo.InvariantCulture));
+            var request = new LinePushRequest(userId!, new[] { text }, retryKey);
+            // 沙箱同步 IPlugin 邊界不能捕獲其 SynchronizationContext；工作在線程池內啟動，
+            // 同步等待十秒有界的 Core 完成才返回，沒有未等待工作，所有 HTTP／取消資源由 Core using 清理。
+            var result = Task.Run(() => client.PushAsync(credential!, request, CancellationToken.None)).GetAwaiter().GetResult();
+            var requestId = Guid.TryParse(result.RequestId, out var parsed) ? parsed.ToString("D", CultureInfo.InvariantCulture) : "unavailable";
+            tracing.Trace("Outcome={0}; Status={1}; RequestId={2}; ExceptionType={3}", result.Outcome,
+                result.StatusCode.HasValue ? ((int)result.StatusCode.Value).ToString(CultureInfo.InvariantCulture) : "no-response",
+                requestId, result.TransportException?.GetType().FullName ?? "none");
+            if (result.Outcome == LinePushOutcome.Retryable)
+            {
+                var message = Texts.GetText("zh-TW", new TextKey("Common.Diagnostics.Retryable"))
+                    .Replace("{retryKey}", retryKey.ToString("D", CultureInfo.InvariantCulture));
+                throw new InvalidPluginExecutionException(message, result.TransportException);
+            }
+        }
+        catch (Exception exception)
+        {
+            // 只追蹤型別，不把原始訊息／堆疊／內文／收件者寫進 Plugin 追蹤；重新拋出保留實例。
+            // 沙箱不寫 Exception.log 或發管理者 LINE；階段五彙總器才負責最終告警。
+            tracing.Trace("ExceptionType={0}", exception.GetType().FullName);
+            throw;
+        }
+    }
+
+    /// <summary>從 JSON 取出明確字串型別，避免隱含轉型或回顯原始設定。</summary>
+    /// <param name="config">只在建構期間存活、長度已限制的設定物件。</param>
+    /// <param name="name">由程式擁有的固定欄位名。</param>
+    /// <returns>不可變設定字串；缺漏或型別錯誤時固定拒絕。</returns>
+    private static string ReadString(JObject config, string name) =>
+        config[name]?.Type == JTokenType.String ? config[name]!.Value<string>()! : throw InvalidConfiguration();
+
+    /// <summary>固定最多三十三個碼元的單人識別驗證，防止群播或任意輸入進傳輸。</summary>
+    /// <param name="value">這個註冊步驟自己的收件者識別，不追蹤或快取。</param>
+    /// <returns>只有單人 LINE 識別格式通過。</returns>
+    private static bool IsValidUserId(string value) =>
+        value.Length == 33 && value[0] == 'U' && value.Skip(1).All(character => character is (>= '0' and <= '9') or (>= 'a' and <= 'f'));
+
+    /// <summary>只發布固定繁中錯誤，不保留含 token／個資的 JSON 解析例外作 InnerException。</summary>
+    /// <returns>不含原始設定資料的 SDK 例外。</returns>
+    private static InvalidPluginExecutionException InvalidConfiguration() =>
+        new(Texts.GetText("zh-TW", new TextKey("Common.Diagnostics.InvalidConfiguration")));
+
+    /// <summary>正式執行使用 UTC；不讀取本機時區、不改動全域時鐘或文化。</summary>
+    /// <returns>這次診斷操作使用的 UTC 時點。</returns>
+    private static DateTimeOffset ReadUtcNow() => DateTimeOffset.UtcNow;
+
+    /// <summary>事件結構名稱只允許有限 ASCII 識別字元；不把可疑外部字串或長文字寫進追蹤。</summary>
+    /// <param name="value">SDK 提供的結構名稱，不是可回顯的自由文字。</param>
+    /// <returns>有效結構名或固定缺省標記。</returns>
+    private static string SafeIdentifier(string value) =>
+        !string.IsNullOrEmpty(value) && value.Length <= 128 &&
+        value.All(character => character is (>= 'a' and <= 'z') or (>= 'A' and <= 'Z') or (>= '0' and <= '9') or '_')
+            ? value : "unavailable";
+}

diff --git a/SpeechMessage.Dynamics.Plugins/SpeechMessage.Dynamics.Plugins.csproj b/SpeechMessage.Dynamics.Plugins/SpeechMessage.Dynamics.Plugins.csproj
new file mode 100644
index 00000000..052cc365
--- /dev/null
+++ b/SpeechMessage.Dynamics.Plugins/SpeechMessage.Dynamics.Plugins.csproj
@@ -0,0 +1,24 @@
+<Project Sdk="Microsoft.NET.Sdk">
+  <PropertyGroup>
+    <TargetFramework>net48</TargetFramework>
+    <SpeechMessageStrictCode>true</SpeechMessageStrictCode>
+    <!-- 嚴格開關與 XML 文件開關必須同在專案本體，避免 SDK 載入時點造成假綠燈。 -->
+    <GenerateDocumentationFile>true</GenerateDocumentationFile>
+    <AssemblyVersion>1.0.0.0</AssemblyVersion>
+    <!-- 建置端以 -p:SpeechMessageBuildNumber 提供單調序號；本機首版預設一，不改 AssemblyVersion。 -->
+    <SpeechMessageBuildNumber Condition="'$(SpeechMessageBuildNumber)' == ''">1</SpeechMessageBuildNumber>
+    <FileVersion>1.0.0.$(SpeechMessageBuildNumber)</FileVersion>
+    <InformationalVersion>1.0.0-p0.$(SpeechMessageBuildNumber)</InformationalVersion>
+    <!-- 使用自訂目標隔離打包與原始測試組件；套件預設會覆寫 bin 並併入整個輸出資料夾。 -->
+    <ILRepackTargetsFile>$(MSBuildThisFileDirectory)../build/PluginMerge.targets</ILRepackTargetsFile>
+  </PropertyGroup>
+  <ItemGroup>
+    <PackageReference Include="Microsoft.NETFramework.ReferenceAssemblies" PrivateAssets="all" />
+    <PackageReference Include="Microsoft.CrmSdk.CoreAssemblies" PrivateAssets="all" />
+    <PackageReference Include="System.Text.Json" PrivateAssets="all" />
+    <PackageReference Include="ILRepack.Lib.MSBuild.Task" PrivateAssets="all" />
+    <ProjectReference Include="../SpeechMessage.Localization/SpeechMessage.Localization.csproj" />
+    <ProjectReference Include="../LineMessagingProcessor.Core/LineMessagingProcessor.Core.csproj" />
+    <InternalsVisibleTo Include="SpeechMessage.Dynamics.Plugins.Tests" />
+  </ItemGroup>
+</Project>
```
